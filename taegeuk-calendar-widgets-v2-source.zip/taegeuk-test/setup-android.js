/* 태극도 생활달력 — 안드로이드 프로젝트 자동 조립
   1) 안드로이드 폴더 만들기  2) 앱 화면 복사  3) 위젯 · 아이콘 · 설정 넣기
   몇 번을 다시 실행해도 괜찮아요. */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const ICON = process.env.TG_ICON || 'E_dojang';      // E_dojang(도장 박공 태극·팔괘 그림 — 지금 아이콘) · D_flag(태극기 방향 바로잡은 새 아이콘) · A_pastel · B_hanji · C_dancheong 중에서 고르기
const PKG = 'com.kimminja.taegeuk';
const ROOT = __dirname;
const AND = path.join(ROOT, 'android');
const MAIN = path.join(AND, 'app', 'src', 'main');
const SKIP_CAP = process.env.TG_SKIP_CAP === '1';   // 시험용

const say = (m) => console.log('  ✓ ' + m);
const run = (cmd) => { console.log('\n> ' + cmd); execSync(cmd, { stdio: 'inherit', cwd: ROOT, shell: true }); };
function copyDir(src, dst, fn) {
  fs.mkdirSync(dst, { recursive: true });
  for (const f of fs.readdirSync(src)) {
    const s = path.join(src, f), d = path.join(dst, f);
    if (fs.statSync(s).isDirectory()) copyDir(s, d, fn);
    else if (fn) fs.writeFileSync(d, fn(fs.readFileSync(s, 'utf8'), f));
    else fs.copyFileSync(s, d);
  }
}

console.log('\n=== 태극도 생활달력 안드로이드 조립을 시작해요 ===');

// 1) 안드로이드 폴더
if (!SKIP_CAP) {
  if (!fs.existsSync(AND)) run('npx cap add android');
  run('npx cap sync android');
}
if (!fs.existsSync(MAIN)) { console.error('\n✗ android 폴더가 없어요. 위에 나온 오류를 알려주세요.'); process.exit(1); }

// 2) 위젯 자바 코드
const javaDir = path.join(MAIN, 'java', ...PKG.split('.'));
copyDir(path.join(ROOT, 'native', 'widget'), path.join(javaDir, 'widget'));
say('위젯 코드 넣음');

// 3) 위젯 그림 · 글자 · 설정 파일
copyDir(path.join(ROOT, 'native', 'res'), path.join(MAIN, 'res'));
say('위젯 그림 넣음');

// 4) MainActivity에 위젯 연결 한 줄
const actFile = path.join(javaDir, 'MainActivity.java');
let act = fs.readFileSync(actFile, 'utf8');
if (!act.includes('TaegeukWidgetPlugin')) {
  act = act.replace(/import com\.getcapacitor\.BridgeActivity;/, 'import android.os.Bundle;\nimport com.getcapacitor.BridgeActivity;\nimport ' + PKG + '.widget.TaegeukWidgetPlugin;');
  if (/public class MainActivity extends BridgeActivity\s*\{\s*\}/.test(act)) {
    act = act.replace(/public class MainActivity extends BridgeActivity\s*\{\s*\}/,
      'public class MainActivity extends BridgeActivity {\n    @Override\n    public void onCreate(Bundle savedInstanceState) {\n        registerPlugin(TaegeukWidgetPlugin.class);\n        super.onCreate(savedInstanceState);\n    }\n}');
  } else {
    act = act.replace(/super\.onCreate\(/, 'registerPlugin(TaegeukWidgetPlugin.class);\n        super.onCreate(');
  }
  fs.writeFileSync(actFile, act);
}
// 4-2) 휴대폰 기능 다리(마이크 권한 · 음성 인식 · 바깥 브라우저 · 연락처) 연결
if (!act.includes('NativeToolsPlugin')) {
  act = act.replace('import ' + PKG + '.widget.TaegeukWidgetPlugin;', 'import ' + PKG + '.widget.TaegeukWidgetPlugin;\nimport ' + PKG + '.widget.NativeToolsPlugin;');
  act = act.replace('registerPlugin(TaegeukWidgetPlugin.class);', 'registerPlugin(TaegeukWidgetPlugin.class);\n        registerPlugin(NativeToolsPlugin.class);');
  fs.writeFileSync(actFile, act);
}
if (!act.includes('NativeToolsPlugin')) { console.error('\n✗ MainActivity에 NativeToolsPlugin을 넣지 못했어요. 이 화면을 찍어 보내주세요.'); process.exit(1); }
say('앱과 위젯 연결');

// 5) AndroidManifest에 위젯 등록 · 알림 권한
const manFile = path.join(MAIN, 'AndroidManifest.xml');
let man = fs.readFileSync(manFile, 'utf8');
if (!man.includes('TodayWidgetProvider')) {
  const rec = `
        <receiver android:name=".widget.TodayWidgetProvider" android:exported="true" android:label="@string/tw_today_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/tw_today_info" />
        </receiver>
        <receiver android:name=".widget.WeekWidgetProvider" android:exported="true" android:label="@string/tw_week_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/tw_week_info" />
        </receiver>
    </application>`;
  man = man.replace(/\s*<\/application>/, rec);
}
if (!man.includes('ChecklistWidgetProvider')) {
  const rec = `
        <receiver android:name=".widget.ChecklistWidgetProvider" android:exported="true" android:label="@string/tw_check_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/tw_check_info" />
        </receiver>
    </application>`;
  man = man.replace(/\s*<\/application>/, rec);
}
if (!man.includes('MonthWidgetProvider')) {
  const rec = `
        <receiver android:name=".widget.MonthWidgetProvider" android:exported="true" android:label="@string/tw_month_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/tw_month_info" />
        </receiver>
    </application>`;
  man = man.replace(/\s*<\/application>/, rec);
}
if (!man.includes('widget.PrayerAlarm')) {
  const rec = `
        <receiver android:name=".widget.PrayerAlarm" android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
            </intent-filter>
        </receiver>
    </application>`;
  man = man.replace(/\s*<\/application>/, rec);
}
// 음성 인식 기능을 찾을 수 있게 (안드로이드 11 이상에서 꼭 필요)
if (!man.includes('android.speech.RecognitionService')) {
  man = man.replace(/(<manifest[^>]*>)/, `$1\n    <queries>\n        <intent>\n            <action android:name="android.speech.RecognitionService" />\n        </intent>\n    </queries>`);
}
// MODIFY_AUDIO_SETTINGS: 이게 없으면 앱 안 웹화면이 마이크를 못 켜요
for (const perm of ['android.permission.POST_NOTIFICATIONS', 'android.permission.SCHEDULE_EXACT_ALARM', 'android.permission.RECEIVE_BOOT_COMPLETED', 'android.permission.RECORD_AUDIO', 'android.permission.MODIFY_AUDIO_SETTINGS']) {
  if (!man.includes(perm)) man = man.replace(/(<manifest[^>]*>)/, `$1\n    <uses-permission android:name="${perm}" />`);
}
man = man.replace(/\s*<receiver\b[^>]*android:name="\.widget\.WeekWidgetProvider"[\s\S]*?<\/receiver>/g, '');
fs.writeFileSync(manFile, man);
say('위젯 등록 · 알림 · 녹음 권한');

// 5-2) 폴더 경로에 한글이 있어도 빌드되게
const gp = path.join(AND, 'gradle.properties');
if (fs.existsSync(gp)) { let g = fs.readFileSync(gp, 'utf8'); if (!g.includes('overridePathCheck')) fs.writeFileSync(gp, g + '\nandroid.overridePathCheck=true\n'); say('경로 확인 설정'); }

// 6) 앱 아이콘
const iconSrc = path.join(ROOT, 'icons', ICON);
for (const d of fs.readdirSync(iconSrc)) {
  const dst = path.join(MAIN, 'res', d);
  fs.mkdirSync(dst, { recursive: true });
  const png = path.join(iconSrc, d, 'ic_launcher.png');
  for (const n of ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png']) fs.copyFileSync(png, path.join(dst, n));
}
const any = path.join(MAIN, 'res', 'mipmap-anydpi-v26');
if (fs.existsSync(any)) fs.rmSync(any, { recursive: true, force: true });
say('앱 아이콘: ' + ICON);

console.log('\n=== 다 됐어요! ===');
console.log('이제 Android Studio에서 이 폴더 안의 "android" 폴더를 열고 ▶ 실행을 누르세요.\n');
