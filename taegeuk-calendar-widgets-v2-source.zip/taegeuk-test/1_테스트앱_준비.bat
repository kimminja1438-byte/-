@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo === 테스트 앱 준비를 시작해요 (처음엔 몇 분 걸려요) ===
call npm install --no-audit --no-fund
if errorlevel 1 goto err
call node setup-android.js
if errorlevel 1 goto err
call node test-suffix.js
if errorlevel 1 goto err
echo.
echo 준비 끝! Android Studio를 열어요. 휴대폰을 USB로 연결하고 초록 실행(▶) 단추를 누르세요.
call npx cap open android
pause
exit /b 0
:err
echo.
echo 오류가 났어요. 이 검은 창을 사진으로 찍어 보내 주세요.
pause
