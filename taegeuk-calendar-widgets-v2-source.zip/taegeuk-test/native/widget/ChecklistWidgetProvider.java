package com.kimminja.taegeuk.widget;
import android.app.PendingIntent;
import android.appwidget.*;
import android.content.*;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StrikethroughSpan;
import android.view.View;
import android.widget.RemoteViews;
import com.kimminja.taegeuk.R;
import org.json.*;
import java.util.*;

/** 일반 할 일과 반복 루틴을 함께 표시, 미완료 먼저. */
public class ChecklistWidgetProvider extends AppWidgetProvider {
    static final String ACTION="com.kimminja.taegeuk.widget.TODO",FOLD="com.kimminja.taegeuk.widget.TODO_FOLD";
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)render(c,m,id);WidgetUpdater.scheduleMidnight(c);}
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle o){render(c,m,id);}
    @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);
        int id=i.getIntExtra("wid",-1);
        if(FOLD.equals(i.getAction())&&id>=0){android.content.SharedPreferences sp=c.getSharedPreferences(WidgetData.PREFS,0);String key="todo_fold_"+id;sp.edit().putBoolean(key,!sp.getBoolean(key,false)).apply();render(c,AppWidgetManager.getInstance(c),id);}
        else if(ACTION.equals(i.getAction())){String date=i.getStringExtra("date"),key=i.getStringExtra("key");
            if(date==null||key==null||WidgetData.tooSoon(c,"todo:"+date+key))return;
            // A stale home-screen tap must never change a different day's routine.
            if(!date.equals(WidgetData.iso(WidgetData.today()))){WidgetUpdater.updateAll(c);return;}
            String msg=key.startsWith("r:")?WidgetData.quickRoutine(c,key.substring(2)):WidgetData.quickTodo(c,date,key.substring(2));
            WidgetUpdater.updateAll(c);WidgetData.toast(c,msg);
        }
    }
    static PendingIntent tap(Context c,String date,String key){Intent i=new Intent(c,ChecklistWidgetProvider.class).setAction(ACTION).setData(android.net.Uri.parse("taegeuk-widget://todo/"+date+"/"+android.net.Uri.encode(key))).putExtra("date",date).putExtra("key",key);return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static void render(Context c,AppWidgetManager mgr,int id){
        JSONObject data=WidgetData.load(c);WidgetData.Theme th=WidgetData.Theme.of(data);Calendar t=WidgetData.today();String date=WidgetData.iso(t);JSONObject d=WidgetData.day(data,date);
        ArrayList<JSONObject> list=new ArrayList<>();JSONArray todos=d==null?null:d.optJSONArray("todos"),routines=WidgetData.routinesToday(data);
        try{if(todos!=null)for(int i=0;i<todos.length();i++){JSONObject x=todos.optJSONObject(i);if(x!=null)list.add(new JSONObject().put("key","t:"+x.optInt("id")).put("text",x.optString("text")).put("done",x.optBoolean("done")));}
            for(int i=0;i<routines.length();i++){JSONObject x=routines.optJSONObject(i);if(x!=null)list.add(new JSONObject().put("key","r:"+x.optString("id")).put("text","↻ "+x.optString("t")).put("done",WidgetData.routineDone(data,x.optString("id"))));}
        }catch(Exception ignored){}
        Collections.sort(list,(a,b)->Boolean.compare(a.optBoolean("done"),b.optBoolean("done")));int done=0;for(JSONObject x:list)if(x.optBoolean("done"))done++;
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.tw_widget_check);float f=WidgetData.scale(data);
        v.setInt(R.id.tw_root,"setBackgroundResource",th.bg);
        for(int x:new int[]{R.id.tw_ck_title,R.id.tw_ck_date,R.id.tw_ck_count,R.id.tw_ck_empty,R.id.tw_ck_edit,R.id.tw_ck_add,R.id.tw_ck_fold,R.id.tw_ck_more}){v.setTextColor(x,th.ink);WidgetData.sz(v,x,x==R.id.tw_ck_title?20:14,f);}
        v.setTextViewText(R.id.tw_ck_date,(t.get(Calendar.MONTH)+1)+"월 "+t.get(Calendar.DAY_OF_MONTH)+"일 "+WidgetData.WD_LONG[t.get(Calendar.DAY_OF_WEEK)-1]);
        v.setTextViewText(R.id.tw_ck_count,list.size()+"개 중 "+done+"개 완료");v.setProgressBar(R.id.tw_ck_progress,Math.max(1,list.size()),done,false);
        boolean folded=c.getSharedPreferences(WidgetData.PREFS,0).getBoolean("todo_fold_"+id,false);
        int height=mgr.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,360);int max=Math.max(1,(height-228)/48);int shown=0;
        v.removeAllViews(R.id.tw_ck_rows);
        for(JSONObject x:list){boolean on=x.optBoolean("done");if(on&&folded)continue;if(shown>=max)break;
            RemoteViews row=new RemoteViews(c.getPackageName(),R.layout.tw_todo_row);
            String title=x.optString("text");SpannableString text=new SpannableString(title);if(on)text.setSpan(new StrikethroughSpan(),0,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            row.setTextViewText(R.id.tw_todo_text,text);row.setTextColor(R.id.tw_todo_text,on?th.sub:th.ink);WidgetData.sz(row,R.id.tw_todo_text,15,f);
            row.setTextViewText(R.id.tw_todo_check,on?"☑":"☐");row.setTextColor(R.id.tw_todo_check,on?0xFF4E8D77:th.sub);
            row.setContentDescription(R.id.tw_todo_check,(on?"완료 취소: ":"완료 체크: ")+title);
            row.setOnClickPendingIntent(R.id.tw_todo_check,tap(c,date,x.optString("key")));
            row.setOnClickPendingIntent(R.id.tw_todo_text,WidgetUpdater.openApp(c,"todo",date));
            v.addView(R.id.tw_ck_rows,row);shown++;
        }
        int remaining=list.size()-(folded?done:0)-shown;
        v.setTextViewText(R.id.tw_ck_more,remaining>0?"+"+remaining+"개 전체 보기 ›":"");v.setViewVisibility(R.id.tw_ck_more,remaining>0?View.VISIBLE:View.GONE);
        v.setViewVisibility(R.id.tw_ck_empty,list.isEmpty()?View.VISIBLE:View.GONE);v.setTextViewText(R.id.tw_ck_empty,d==null?"앱을 한 번 열어주세요":"오늘 할 일을 추가해보세요");
        v.setTextViewText(R.id.tw_ck_fold,"완료한 일 "+done+"개 "+(folded?"펼치기 ▾":"접기 ▴"));
        Intent fold=new Intent(c,ChecklistWidgetProvider.class).setAction(FOLD).putExtra("wid",id);
        v.setOnClickPendingIntent(R.id.tw_ck_fold,PendingIntent.getBroadcast(c,id,fold,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
        for(int x:new int[]{R.id.tw_ck_add,R.id.tw_ck_edit,R.id.tw_ck_more,R.id.tw_ck_empty})v.setOnClickPendingIntent(x,WidgetUpdater.openApp(c,"todo",date));
        v.setOnClickPendingIntent(R.id.tw_refresh,WidgetUpdater.quick(c,"refresh"));
        v.setOnClickPendingIntent(R.id.tw_t_undo,WidgetUpdater.quick(c,"undo"));
        mgr.updateAppWidget(id,v);
    }
}
