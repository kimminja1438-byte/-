package com.kimminja.taegeuk.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.widget.Toast;

import com.kimminja.taegeuk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

/** 앱이 보내준 위젯 정보를 읽고, 오늘 날짜에 맞는 내용을 골라줘요. */
public final class WidgetData {
    static final String PREFS = "taegeuk_widget";
    static final String KEY = "data";

    private WidgetData() {}

    static synchronized boolean acceptSnapshot(Context ctx,String json){
        if(pending(ctx).length()>0)return false;
        save(ctx,json);return true;
    }
    static synchronized boolean tooSoon(Context ctx,String kind){
        SharedPreferences p=ctx.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        long now=android.os.SystemClock.elapsedRealtime(),last=p.getLong("tap_"+kind,0);
        if(last>0&&now>=last&&now-last<900)return true;
        p.edit().putLong("tap_"+kind,now).apply();return false;
    }
    private static void setSlot(JSONObject d,int index,boolean on){
        try{JSONArray a=d.optJSONArray("prayers");if(a==null){a=new JSONArray();int pc=d.optInt("pc");for(int i=0;i<d.optInt("pt",4);i++)a.put(i<pc);d.put("prayers",a);}
            a.put(index,on);JSONArray slots=d.optJSONArray("slots");if(slots!=null)slots.put(index,on?1:0);
        }catch(Exception ignored){}
    }
    private static int firstUnchecked(JSONObject d){JSONArray a=d.optJSONArray("prayers");for(int i=0;i<d.optInt("pt",4);i++)if(a==null?i>=d.optInt("pc"):!a.optBoolean(i))return i;return -1;}
    static void save(Context ctx, String json) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply();
    }

    static JSONObject load(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            String s = p.getString(KEY, null);
            JSONObject o = s == null ? null : new JSONObject(s);
            if (o != null) {
                JSONArray e = o.optJSONArray("early");
                StringBuilder sb = new StringBuilder(",");
                if (e != null) for (int i = 0; i < e.length(); i++) sb.append(e.optString(i)).append(',');
                early = sb.toString();
            }
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    /** 주일 · 치성은 전날 밤 11시 30분(자시)부터 그날로 쳐요. 그런 날짜들 (",2026-10-07,2026-10-12,") */
    static volatile String early = ",";
    static final int EARLY_MIN = 23 * 60 + 30;

    /** 앱에서 '글씨 크게 보기'를 켜면 위젯 글씨도 1.25배 */
    static float scale(JSONObject data) {
        if (data == null) return 1f;
        double w = data.optDouble("wscale", 0);
        if (w >= 0.8 && w <= 1.8) return (float) w;
        return data.optBoolean("big") ? 1.25f : 1f;
    }

    static void sz(android.widget.RemoteViews v, int id, float sp, float f) {
        v.setTextViewTextSize(id, android.util.TypedValue.COMPLEX_UNIT_SP, sp * f);
    }

    static String iso(Calendar c) {
        return String.format(Locale.US, "%04d-%02d-%02d",
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static Calendar today() {
        Calendar c = Calendar.getInstance();
        if (c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE) >= EARLY_MIN) {
            Calendar t = (Calendar) c.clone();
            t.add(Calendar.DAY_OF_MONTH, 1);
            if (early.contains("," + iso(t) + ",")) c = t;   // 밤 11:30 이후 + 내일이 주일/치성 → 이미 그날
        }
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    static JSONObject day(JSONObject data, String iso) {
        if (data == null) return null;
        JSONArray days = data.optJSONArray("days");
        if (days == null) return null;
        for (int i = 0; i < days.length(); i++) {
            JSONObject d = days.optJSONObject(i);
            if (d != null && iso.equals(d.optString("k"))) return d;
        }
        return null;
    }

    /** 오늘부터 며칠 뒤인지 (같은 날 = 0) */
    static int daysBetween(Calendar from, String iso) {
        try {
            String[] p = iso.split("-");
            Calendar t = Calendar.getInstance();
            t.clear();
            t.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]));
            long diff = t.getTimeInMillis() - from.getTimeInMillis();
            return (int) Math.round(diff / 86400000.0);
        } catch (Exception e) {
            return -1;
        }
    }

    /** 다음 치성: {이름, D-day} 또는 null */
    static Object[] nextChiseong(JSONObject data, Calendar today) {
        if (data == null) return null;
        JSONArray a = data.optJSONArray("chis");
        if (a == null) return null;
        for (int i = 0; i < a.length(); i++) {
            JSONObject c = a.optJSONObject(i);
            if (c == null) continue;
            int n = daysBetween(today, c.optString("k"));
            if (n >= 0) return new Object[]{c.optString("name"), n, c.optString("k")};
        }
        return null;
    }

    /** 성금 마감까지 남은 날 (보여줄 때가 아니면 -1) */
    static int offerDday(JSONObject data, Calendar today) {
        if (data == null) return -1;
        JSONObject offer = data.optJSONObject("offer");
        if (offer == null) return -1;
        String mk = String.format(Locale.US, "%04d-%02d", today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1);
        JSONObject o = offer.optJSONObject(mk);
        if (o == null || o.optInt("left", 0) <= 0) return -1;
        int d = today.get(Calendar.DAY_OF_MONTH);
        int start = o.optInt("start", 2), due = o.optInt("due", 20);
        if (d < start || d > due) return -1;
        return due - d;
    }

    static String dday(int n) {
        return n == 0 ? "D-day" : "D-" + n;
    }

    /** 앱 테마에 맞춘 색 */
    static final class Theme {
        final int bg, chip, todayCell, logo, ink, sub, accent, blue;
        final boolean photo;
        int photoRes = R.drawable.tw_dc_banner;

        Theme(int bg, int chip, int todayCell, int logo, int ink, int sub, int accent, int blue) {
            this(bg, chip, todayCell, logo, ink, sub, accent, blue, false);
        }

        Theme(int bg, int chip, int todayCell, int logo, int ink, int sub, int accent, int blue, boolean photo) {
            this.bg = bg; this.chip = chip; this.todayCell = todayCell; this.logo = logo;
            this.ink = ink; this.sub = sub; this.accent = accent; this.blue = blue; this.photo = photo;
        }

        /** 배경 사진 없이 깔끔한 바탕 + 앱 테마 빛깔만 (달력이 잘 보이게) */
        static Theme of(JSONObject data) {
            String t = data == null ? "pastel" : data.optString("theme", "pastel");
            switch (t) {
                case "hanji":       // 한지: 누런 종이빛 · 붉은 먹
                    return new Theme(R.drawable.tw_pbg_hanji, R.drawable.tw_pchip_hanji, R.drawable.tw_ptoday_hanji,
                            R.drawable.tw_taegeuk_flag, 0xFF1E232B, 0xFF7D7466, 0xFFB8322F, 0xFF1D4F8B);
                case "dancheong":   // 단청: 상아빛 바탕 · 청록 단추 · 단청 빨강
                    return new Theme(R.drawable.tw_pbg_dancheong, R.drawable.tw_pchip_dancheong, R.drawable.tw_ptoday_dancheong,
                            R.drawable.tw_taegeuk_flag, 0xFF1F3B35, 0xFF6E7C75, 0xFFB8352B, 0xFF1F6F63);
                case "night":       // 밤: 짙은 남색
                    return new Theme(R.drawable.tw_bg_plain_dark, R.drawable.tw_chip_plain_dark, R.drawable.tw_today_plain_dark,
                            R.drawable.tw_taegeuk_pastel, 0xFFE6EDF3, 0xFF98A6B3, 0xFFF4C77A, 0xFF7AB6E6);
                case "nature":      // 자연: 연둣빛 바탕 · 숲 초록
                    return new Theme(R.drawable.tw_pbg_nature, R.drawable.tw_pchip_nature, R.drawable.tw_ptoday_nature,
                            R.drawable.tw_taegeuk_nature, 0xFF1B2E23, 0xFF5B6D62, 0xFF2F7D4F, 0xFF2F6FBF);
                default:            // 파스텔: 연분홍 바탕
                    return new Theme(R.drawable.tw_pbg_pastel, R.drawable.tw_pchip_pastel, R.drawable.tw_ptoday_pastel,
                            R.drawable.tw_taegeuk_pastel, 0xFF203A52, 0xFF7A8896, 0xFFE8739B, 0xFF4F9FD8);
            }
        }
    }

    /** 이모티콘 그림(앱이 보내준 data 주소)을 작은 그림으로 바꿔요. 실패하면 null */
    private static final HashMap<String, Bitmap> ICON_CACHE = new HashMap<>();
    private static String iconGen = "";

    static Bitmap icon(JSONObject data, String id) {
        if (data == null || id == null || id.isEmpty()) return null;
        String gen = data.optString("revision",data.optString("gen"));
        if (!gen.equals(iconGen)) { ICON_CACHE.clear(); iconGen = gen; }
        if (ICON_CACHE.containsKey(id)) return ICON_CACHE.get(id);
        Bitmap bm = null;
        try {
            JSONObject icons = data.optJSONObject("icons");
            String src = icons == null ? "" : icons.optString(id);
            int comma = src.indexOf(',');
            if (comma > 0) {
                byte[] bytes = Base64.decode(src.substring(comma + 1), Base64.DEFAULT);
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
                int sample = 1;
                while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= 64) sample *= 2;
                o = new BitmapFactory.Options();
                o.inSampleSize = sample;
                bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
            }
        } catch (Exception e) {
            bm = null;
        }
        ICON_CACHE.put(id, bm);
        return bm;
    }

    /** 그날 이모티콘 id 목록 (최대 2개) */
    static String emo(JSONObject d, int i) {
        if (d == null) return null;
        JSONArray a = d.optJSONArray("emo");
        return a == null || a.length() <= i ? null : a.optString(i, null);
    }

    /** 일정·할 일 한 개를 글자로 (앱이 글자나 {title,time} / {text} 모양으로 보내요) */
    static String itemText(Object o, boolean withTime) {
        if (o == null) return "";
        if (o instanceof JSONObject) {
            JSONObject j = (JSONObject) o;
            String t = j.optString("title", j.optString("text", "")).trim();
            String tm = withTime ? j.optString("time", "").trim() : "";
            return (tm.isEmpty() ? "" : tm + " ") + t;
        }
        String s = String.valueOf(o).trim();
        return "null".equals(s) ? "" : s;
    }

    /** 할 일이 끝났는지 */
    static boolean itemDone(Object o) {
        return o instanceof JSONObject && ((JSONObject) o).optBoolean("done", false);
    }

    /** 그날 일정 한 줄: "10:00 제목 +2" */
    static String schLine(JSONObject d, boolean withTime) {
        if (d == null) return "";
        JSONArray a = d.optJSONArray("items");
        if (a == null || a.length() == 0) return "";
        String t = itemText(a.opt(0), withTime);
        int more = a.length() - 1;
        return t + (more > 0 ? " +" + more : "");
    }


    /* ===== 위젯에서 바로 체크 =====
       위젯 단추(기도 ✓ · 수련 +1 · 공부)를 누르면 앱을 열지 않고 바로 숫자가 바뀌어요.
       누른 기록은 "pending" 에 잠깐 적어 두었다가, 다음에 앱을 열면 앱이 가져가서 달력에 합쳐요. */
    static final String PENDING = "pending";

    static JSONArray pending(Context ctx) {
        try {
            String s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PENDING, "[]");
            return new JSONArray(s);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static void savePending(Context ctx, JSONArray a) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(PENDING, a.toString()).apply();
    }

    /* 오늘 위젯에서 누른 순서 (앱이 가져간 뒤에도 ↩ 되돌리기가 되게) */
    static final String HIST = "hist";

    static JSONArray hist(Context ctx) {
        try { return new JSONArray(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(HIST, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private static void saveHist(Context ctx, JSONArray a) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(HIST, a.toString()).apply();
    }

    private static void addHist(Context ctx, JSONObject it) {
        String t = iso(today());
        JSONArray h = hist(ctx), nh = new JSONArray();
        for (int i = 0; i < h.length(); i++) { JSONObject o = h.optJSONObject(i); if (o != null && t.equals(o.optString("k"))) nh.put(o); }
        nh.put(it);
        while (nh.length() > 30) nh.remove(0);
        saveHist(ctx, nh);
    }

    private static String inverse(String kind) {
        switch (kind) {
            case "prayer": return "prayer_off";
            case "suryeon": return "suryeon_off";
            case "study_on": return "study_off";
            case "study_off": return "study_on";
            case "routine_on": return "routine_off";
            case "routine_off": return "routine_on";
            case "chiseong_on": return "chiseong_off";
            case "chiseong_off": return "chiseong_on";
            case "todo_on": return "todo_off";
            case "todo_off": return "todo_on";
            default: return "";
        }
    }

    /** 앱이 가져가요: 지금까지 위젯에서 누른 기록을 주고 비워요 */
    static synchronized JSONArray takePending(Context ctx) {
        JSONArray a = pending(ctx);
        return a;
    }

    static String eventKey(JSONObject o){return o.optString("k")+"|"+o.optLong("ts")+"|"+o.optString("kind")+"|"+o.optString("id");}
    static synchronized void acknowledge(Context ctx,JSONArray keys){
        java.util.HashSet<String> done=new java.util.HashSet<>();for(int i=0;i<keys.length();i++)done.add(keys.optString(i));
        JSONArray keep=new JSONArray(),a=pending(ctx);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&!done.contains(eventKey(o)))keep.put(o);}savePending(ctx,keep);
    }
    /** 오늘 칸 숫자를 바로 바꿔요. kind: prayer · suryeon · study. 바뀌었으면 안내 글, 아니면 null */
    static synchronized String quick(Context ctx, String kind) {
        JSONObject data = load(ctx);
        if (data == null) return "앱을 한 번 열어주세요";
        String iso = iso(today());
        JSONObject d = day(data, iso);
        if (d == null) return "앱을 한 번 열어주세요";
        String msg;
        String rec = kind;
        int changedSlot=-1;
        try {
            if ("prayer".equals(kind)) {
                int pt = d.optInt("pt", 4), pc = d.optInt("pc", 0);
                if (pt > 0 && pc >= pt) return "오늘 기도를 다 모셨어요 (" + pc + "/" + pt + ")";
                changedSlot=firstUnchecked(d);if(changedSlot<0)return "오늘 기도를 다 모셨어요";
                setSlot(d,changedSlot,true);d.put("pc", pc + 1);
                markPrayerTime(data, true);
                msg = "🇰🇷 기도 " + (pc + 1) + (pt > 0 ? "/" + pt : "") + " 체크했어요";
            } else if ("suryeon".equals(kind)) {
                int sr = d.optInt("sr", 0);
                if (sr >= 3) return "수련은 하루 3번까지 적을 수 있어요";
                d.put("sr", sr + 1);
                msg = "🕯 수련 " + (sr + 1) + "번 적었어요";
            } else if ("chiseong".equals(kind)) {
                boolean ch = !d.optBoolean("ch", false);
                d.put("ch", ch);
                rec = ch ? "chiseong_on" : "chiseong_off";
                msg = ch ? "🪷 치성 모심 ✓" : "치성 체크를 지웠어요";
            } else if ("study".equals(kind)) {
                boolean st = !d.optBoolean("st", false);
                d.put("st", st);
                rec = st ? "study_on" : "study_off";
                msg = st ? "🔖 오늘 공부 갔어요 ✓" : "🔖 공부 표시를 지웠어요";
            } else {
                return null;
            }
            JSONObject q = data.optJSONObject("todayQuick");
            Calendar tc = today();
            String appKey = tc.get(Calendar.YEAR) + "-" + (tc.get(Calendar.MONTH) + 1) + "-" + tc.get(Calendar.DAY_OF_MONTH);
            if (q != null && appKey.equals(q.optString("key"))) {
                q.put("prayerCount", d.optInt("pc"));
                q.put("suryeonCount", d.optInt("sr"));
                q.put("study", d.optBoolean("st"));
            }
            save(ctx, data.toString());
            JSONArray a = pending(ctx);
            JSONObject it = new JSONObject();
            it.put("k", iso);
            it.put("kind", rec);
            if(changedSlot>=0)it.put("slot",changedSlot);
            it.put("ts", System.currentTimeMillis());
            a.put(it);
            savePending(ctx, a);
            addHist(ctx, it);
        } catch (Exception e) {
            return null;
        }
        return msg;
    }

    /** 메인 달력 위젯에서 할 일을 눌러 ✓ / 해제 (앱을 열지 않아요) */
    static synchronized String quickTodo(Context ctx, String iso, String tid) {
        JSONObject data = load(ctx);
        if (data == null) return "앱을 한 번 열어주세요";
        JSONObject d = day(data, iso);
        JSONArray todos = d == null ? null : d.optJSONArray("todos");
        if (todos == null) return null;
        try {
            for (int i = 0; i < todos.length(); i++) {
                JSONObject t = todos.optJSONObject(i);
                if (t == null || !tid.equals(String.valueOf(t.optInt("id")))) continue;
                boolean on = !t.optBoolean("done");
                t.put("done", on);
                save(ctx, data.toString());
                JSONObject it = new JSONObject();
                it.put("k", iso);
                it.put("kind", on ? "todo_on" : "todo_off");
                it.put("id", tid);
                it.put("text",t.optString("text"));
                it.put("ts", System.currentTimeMillis());
                JSONArray a = pending(ctx);
                a.put(it);
                savePending(ctx, a);
                if (iso.equals(iso(today()))) addHist(ctx, it);
                return on ? "✓ 했어요" : "체크를 지웠어요";
            }
        } catch (Exception e) { /* 그대로 */ }
        return null;
    }

    /** 기도 알림의 [✓ 모셨어요]: 그 날짜 · 그 시간 기도를 체크해요 (앱을 열 때 달력에 들어가요) */
    static synchronized String markPrayer(Context ctx, String iso, int slot, String name) {
        if (iso == null || iso.isEmpty()) iso = iso(today());
        try {
            JSONObject existing=load(ctx),ed=day(existing,iso);
            JSONArray ep=ed==null?null:ed.optJSONArray("prayers");
            if(ep!=null&&slot>=0&&ep.optBoolean(slot))return "이미 체크한 기도예요";
            JSONObject it = new JSONObject();
            it.put("k", iso);
            it.put("kind", "prayer");
            if (slot >= 0) it.put("slot", slot);
            it.put("ts", System.currentTimeMillis());
            JSONArray a = pending(ctx);
            a.put(it);
            savePending(ctx, a);
            if (iso.equals(iso(today()))) addHist(ctx, it);
            JSONObject data = load(ctx);
            if (data != null) {
                JSONObject d = day(data, iso);
                if (d != null) {
                    int pt = d.optInt("pt", 4), pc = d.optInt("pc", 0);
                    int sl=slot>=0?slot:firstUnchecked(d);if(sl>=0)setSlot(d,sl,true);
                    d.put("pc", pt > 0 ? Math.min(pt, pc + 1) : pc + 1);
                }
                if (iso.equals(iso(today()))) {
                    JSONArray pts = data.optJSONArray("prayerTimes");
                    JSONObject p = pts != null && slot >= 0 && slot < pts.length() ? pts.optJSONObject(slot) : null;
                    if (p != null) p.put("done", true); else markPrayerTime(data, true);
                }
                save(ctx, data.toString());
            }
        } catch (Exception e) {
            return "체크하지 못했어요. 앱에서 체크해주세요.";
        }
        return "🇰🇷 " + (name == null || name.isEmpty() ? "" : name + " ") + "기도 체크했어요";
    }

    /** 위젯에서 누른 것을 마지막 것부터 하나씩 되돌려요 (오늘 누른 것이면 앱을 열었어도 돼요) */
    static synchronized String undo(Context ctx) {
        String t = iso(today());
        JSONArray h = hist(ctx);
        int idx = -1;
        for (int i = h.length() - 1; i >= 0; i--) { JSONObject o = h.optJSONObject(i); if (o != null && t.equals(o.optString("k"))) { idx = i; break; } }
        if (idx < 0) return "되돌릴 기록이 없어요.\n앱에서 그날 기도 칸을 눌러 고쳐주세요.";
        JSONObject last = h.optJSONObject(idx);
        h.remove(idx);
        saveHist(ctx, h);
        // Keep the original event until acknowledged. Its inverse is another event,
        // so undo is safe even while the web app is importing the original event.
        JSONArray rest = pending(ctx);
        try {
            JSONObject inv = new JSONObject();
            inv.put("k", last.optString("k"));inv.put("kind", inverse(last.optString("kind")));
            if (!last.optString("id").isEmpty()) inv.put("id",last.optString("id"));
            if(last.has("slot"))inv.put("slot",last.optInt("slot"));
            if(last.has("text"))inv.put("text",last.optString("text"));
            inv.put("ts",System.currentTimeMillis());rest.put(inv);
        } catch(Exception ignored){}
        savePending(ctx, rest);
        JSONObject data = load(ctx);
        if (data == null || last == null) return "되돌렸어요";
        JSONObject d = day(data, last.optString("k"));
        try {
            String kind = last.optString("kind");
            if (d != null) {
                if ("prayer".equals(kind)) { int sl=last.optInt("slot",-1);JSONArray pr=d.optJSONArray("prayers");boolean changed=sl<0||pr==null||pr.optBoolean(sl);if(changed){if(sl>=0)setSlot(d,sl,false);d.put("pc", Math.max(0, d.optInt("pc") - 1)); markPrayerTime(data, false);} }
                else if ("suryeon".equals(kind)) d.put("sr", Math.max(0, d.optInt("sr") - 1));
                else if ("study_on".equals(kind)) d.put("st", false);
                else if ("study_off".equals(kind)) d.put("st", true);
                else if ("chiseong_on".equals(kind)) d.put("ch", false);
                else if ("chiseong_off".equals(kind)) d.put("ch", true);
            }
            if (("todo_on".equals(kind) || "todo_off".equals(kind)) && d != null && d.optJSONArray("todos") != null) {
                JSONArray ts = d.optJSONArray("todos");
                for (int i = 0; i < ts.length(); i++) {
                    JSONObject tt = ts.optJSONObject(i);
                    if (tt != null && last.optString("id").equals(String.valueOf(tt.optInt("id")))) tt.put("done", "todo_off".equals(kind));
                }
            }
            if (("routine_on".equals(kind) || "routine_off".equals(kind)) && !last.optString("id").isEmpty()) {
                JSONObject rd = data.optJSONObject("rdone");
                if (rd == null) { rd = new JSONObject(); data.put("rdone", rd); }
                String rk = last.optString("k");
                JSONArray a2 = rd.optJSONArray(rk), na = new JSONArray();
                String rid = last.optString("id");
                if (a2 != null) for (int i = 0; i < a2.length(); i++) if (!rid.equals(a2.optString(i))) na.put(a2.optString(i));
                if ("routine_off".equals(kind)) na.put(rid);
                rd.put(rk, na);
            }
            save(ctx, data.toString());
        } catch (Exception e) { /* 그대로 둬요 */ }
        return "↩ 방금 누른 것을 되돌렸어요";
    }

    static void toast(Context ctx, String msg) {
        if (msg == null) return;
        try { Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_SHORT).show(); } catch (Exception e) { /* 조용히 */ }
    }

    /** 위젯 아래 "오늘" 한 줄: 기도 2/4 · 수련 1 · 공부 ✓ */
    static String todaySummary(JSONObject d) {
        if (d == null) return "앱을 한 번 열어주세요";
        int pt = d.optInt("pt", 0);
        return "기도 " + d.optInt("pc") + (pt > 0 ? "/" + pt : "") + "  ·  수련 " + d.optInt("sr") + "  ·  공부 " + (d.optBoolean("st") ? "✓" : "–");
    }


    /* ===== 루틴(체크리스트) · 다음 기도 · 연속 기록 ===== */

    /** 앱이 보낸 정보가 오늘 것인지 (날짜가 바뀌었는데 앱을 안 열었으면 시간·연속 기록은 숨겨요) */
    static boolean fresh(JSONObject data) {
        return data != null && iso(today()).equals(data.optString("gen"));
    }

    /** 오늘 해야 할 루틴 목록 [{id,t}] */
    static JSONArray routinesToday(JSONObject data) {
        JSONArray out = new JSONArray();
        if (data == null) return out;
        JSONArray rs = data.optJSONArray("routines");
        if (rs == null) return out;
        Calendar t = today();
        int w = t.get(Calendar.DAY_OF_WEEK) - 1;
        JSONObject d = day(data, iso(t));
        boolean juil = d != null && d.optBoolean("juil");
        for (int i = 0; i < rs.length(); i++) {
            JSONObject r = rs.optJSONObject(i);
            if (r == null) continue;
            Object days = r.opt("days");
            boolean on;
            if (days instanceof JSONArray) {
                on = false;
                JSONArray a = (JSONArray) days;
                for (int j = 0; j < a.length(); j++) if (a.optInt(j, -1) == w) on = true;
            } else if ("juil".equals(String.valueOf(days))) {
                on = juil;
            } else {
                on = true;
            }
            if (on) out.put(r);
        }
        return out;
    }

    static boolean routineDone(JSONObject data, String id) {
        if (data == null) return false;
        JSONObject rd = data.optJSONObject("rdone");
        JSONArray a = rd == null ? null : rd.optJSONArray(iso(today()));
        if (a == null) return false;
        for (int i = 0; i < a.length(); i++) if (id.equals(a.optString(i))) return true;
        return false;
    }

    /** 루틴 하나를 체크/해제 (앱을 열지 않아요) */
    static synchronized String quickRoutine(Context ctx, String id) {
        JSONObject data = load(ctx);
        if (data == null) return "앱을 한 번 열어주세요";
        String iso = iso(today());
        try {
            JSONObject rd = data.optJSONObject("rdone");
            if (rd == null) { rd = new JSONObject(); data.put("rdone", rd); }
            JSONArray a = rd.optJSONArray(iso);
            JSONArray na = new JSONArray();
            boolean was = false;
            if (a != null) for (int i = 0; i < a.length(); i++) {
                if (id.equals(a.optString(i))) was = true; else na.put(a.optString(i));
            }
            if (!was) na.put(id);
            rd.put(iso, na);
            save(ctx, data.toString());
            JSONArray p = pending(ctx);
            JSONObject it = new JSONObject();
            it.put("k", iso);
            it.put("kind", was ? "routine_off" : "routine_on");
            it.put("id", id);
            it.put("ts", System.currentTimeMillis());
            p.put(it);
            savePending(ctx, p);
            addHist(ctx, it);
            JSONArray list = routinesToday(data);
            int done = 0;
            for (int i = 0; i < list.length(); i++) if (routineDone(data, list.optJSONObject(i).optString("id"))) done++;
            if (was) return "체크를 지웠어요 (" + done + "/" + list.length() + ")";
            return done == list.length() ? "🎉 오늘 루틴을 다 했어요!" : "✓ 체크했어요 (" + done + "/" + list.length() + ")";
        } catch (Exception e) {
            return null;
        }
    }

    /** "다음 기도 오후 1:30 (미시)" — 오늘 다 모셨으면 "오늘 기도를 다 모셨어요" */
    static String nextPrayer(JSONObject data) {
        if (!fresh(data)) return "";
        JSONArray pts = data.optJSONArray("prayerTimes");
        if (pts == null || pts.length() == 0) return "";
        Calendar now = Calendar.getInstance();
        int nm = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        JSONObject firstOpen = null, next = null;
        for (int i = 0; i < pts.length(); i++) {
            JSONObject p = pts.optJSONObject(i);
            if (p == null || p.optBoolean("done")) continue;
            if (firstOpen == null) firstOpen = p;
            if (next == null && p.optInt("m", -1) >= nm) next = p;
        }
        if (firstOpen == null) return "오늘 기도를 다 모셨어요 🙏";
        JSONObject p = next != null ? next : firstOpen;
        String n = p.optString("n");
        return (next != null ? "다음 기도 " : "남은 기도 ") + p.optString("t") + (n.isEmpty() ? "" : " (" + n + ")");
    }

    /** 기도 이어간 날 수 (오늘 기도했으면 오늘 포함) */
    static int streak(JSONObject data) {
        if (!fresh(data)) return 0;
        JSONObject d = day(data, iso(today()));
        return data.optInt("streakPrev", 0) + (d != null && d.optInt("pc") > 0 ? 1 : 0);
    }

    /** 위젯에서 기도를 체크하면 기도 시간 목록에서도 첫 빈칸을 채워요 */
    private static void markPrayerTime(JSONObject data, boolean on) {
        JSONArray pts = data.optJSONArray("prayerTimes");
        if (pts == null) return;
        try {
            if (on) {
                for (int i = 0; i < pts.length(); i++) { JSONObject p = pts.optJSONObject(i); if (p != null && !p.optBoolean("done")) { p.put("done", true); return; } }
            } else {
                for (int i = pts.length() - 1; i >= 0; i--) { JSONObject p = pts.optJSONObject(i); if (p != null && p.optBoolean("done")) { p.put("done", false); return; } }
            }
        } catch (Exception e) { /* 그대로 */ }
    }

    static final String[] WD = {"일", "월", "화", "수", "목", "금", "토"};
    static final String[] WD_LONG = {"일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"};
}
