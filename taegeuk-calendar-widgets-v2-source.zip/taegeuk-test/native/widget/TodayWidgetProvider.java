package com.kimminja.taegeuk.widget;
import android.appwidget.*;
import android.content.*;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import com.kimminja.taegeuk.R;
import org.json.*;
import java.util.Calendar;

/** 오늘 기록: 태극 기도 · 오늘 마음 · 한 줄 메모. */
public class TodayWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)render(c,m,id);WidgetUpdater.scheduleMidnight(c);}
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle o){render(c,m,id);}
    @Override public void onReceive(Context ctx,Intent intent){
        super.onReceive(ctx,intent);String a=intent.getAction();
        if(WidgetUpdater.ACTION_MIDNIGHT.equals(a)||Intent.ACTION_TIME_CHANGED.equals(a)||Intent.ACTION_TIMEZONE_CHANGED.equals(a)){
            WidgetUpdater.updateAll(ctx);PrayerAlarm.rearm(ctx);
        }else if(WidgetUpdater.ACTION_QUICK.equals(a)){
            String kind=intent.getStringExtra(WidgetUpdater.EXTRA_KIND);
            if("refresh".equals(kind)){WidgetUpdater.updateAll(ctx);return;}
            if(kind==null||WidgetData.tooSoon(ctx,kind))return;
            String msg="undo".equals(kind)?WidgetData.undo(ctx):kind.startsWith("routine:")?WidgetData.quickRoutine(ctx,kind.substring(8)):WidgetData.quick(ctx,kind);
            WidgetUpdater.updateAll(ctx);WidgetData.toast(ctx,msg);
        }
    }
    static void render(Context ctx,AppWidgetManager mgr,int id){
        JSONObject data=WidgetData.load(ctx);WidgetData.Theme th=WidgetData.Theme.of(data);
        Calendar t=WidgetData.today();String iso=WidgetData.iso(t);JSONObject d=WidgetData.day(data,iso);
        RemoteViews v=new RemoteViews(ctx.getPackageName(),R.layout.tw_widget_today);float f=WidgetData.scale(data);
        v.setInt(R.id.tw_root,"setBackgroundResource",th.bg);
        for(int x:new int[]{R.id.tw_brand,R.id.tw_md,R.id.tw_rec,R.id.tw_mood,R.id.tw_memo,R.id.tw_b_prayer,R.id.tw_details,R.id.tw_t_undo}){v.setTextColor(x,th.ink);WidgetData.sz(v,x,x==R.id.tw_brand?19:14,f);}
        v.setTextViewText(R.id.tw_md,(t.get(Calendar.MONTH)+1)+"월 "+t.get(Calendar.DAY_OF_MONTH)+"일 "+WidgetData.WD_LONG[t.get(Calendar.DAY_OF_WEEK)-1]);
        int pc=d==null?0:d.optInt("pc"),pt=d==null?4:d.optInt("pt",4);
        v.setImageViewBitmap(R.id.tw_prayer_art,WidgetArt.prayer(d,220));
        v.setContentDescription(R.id.tw_prayer_art,"기도 "+pc+"/"+pt+"회 · 눌러서 기록 수정");
        v.setTextViewText(R.id.tw_rec,d==null?"앱을 한 번 열어주세요":"기도 "+pc+"/"+pt+"회"+(pc>=pt?" ✓":""));
        String mood=d==null?"":d.optString("mood"),memo=d==null?"":d.optString("memo");
        v.setTextViewText(R.id.tw_mood,"오늘 마음\n"+(mood.isEmpty()?"＋ 마음 고르기":mood));
        v.setTextViewText(R.id.tw_memo,"한 줄 메모\n"+(memo.isEmpty()?"＋ 메모 쓰기":memo));
        v.setOnClickPendingIntent(R.id.tw_prayer_art,WidgetUpdater.openApp(ctx,"prayer",iso));
        v.setOnClickPendingIntent(R.id.tw_rec,WidgetUpdater.openApp(ctx,"prayer",iso));
        v.setOnClickPendingIntent(R.id.tw_mood,WidgetUpdater.openApp(ctx,"mood",iso));
        v.setOnClickPendingIntent(R.id.tw_memo,WidgetUpdater.openApp(ctx,"memo",iso));
        v.setTextViewText(R.id.tw_b_prayer,pc>=pt?"기도 완료 ✓":"＋ 기도 체크");
        v.setOnClickPendingIntent(R.id.tw_b_prayer,pc>=pt?WidgetUpdater.openApp(ctx,"prayer",iso):WidgetUpdater.quick(ctx,"prayer"));
        v.setOnClickPendingIntent(R.id.tw_details,WidgetUpdater.openApp(ctx,"day",iso));
        v.setOnClickPendingIntent(R.id.tw_t_undo,WidgetUpdater.quick(ctx,"undo"));
        v.setOnClickPendingIntent(R.id.tw_refresh,WidgetUpdater.quick(ctx,"refresh"));
        mgr.updateAppWidget(id,v);
    }
}
