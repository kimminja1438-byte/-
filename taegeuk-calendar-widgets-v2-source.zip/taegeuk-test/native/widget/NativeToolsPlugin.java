package com.kimminja.taegeuk.widget;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.util.ArrayList;

/**
 * 앱 화면(웹)이 휴대폰 기능을 직접 쓰게 해 주는 다리.
 * - 마이크 권한 묻기 · 앱 설정 열기
 * - 음성 인식(말 → 글자): 앱 안 웹화면은 음성 인식을 못 해서, 휴대폰의 음성 인식을 직접 불러요
 * - 크롬 등 바깥 브라우저로 주소 열기
 * - 연락처에서 한 사람 고르기 (전체 연락처 권한 없이)
 */
@CapacitorPlugin(
    name = "NativeTools",
    permissions = { @Permission(alias = "microphone", strings = { Manifest.permission.RECORD_AUDIO }) }
)
public class NativeToolsPlugin extends Plugin {

    private SpeechRecognizer recognizer;
    private boolean listening = false;
    private String language = "ko-KR";
    private final Handler main = new Handler(Looper.getMainLooper());

    /* ---------- 마이크 권한 ---------- */
    @PluginMethod
    public void requestMicrophonePermission(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) {
            call.resolve(new JSObject().put("granted", true));
            return;
        }
        requestPermissionForAlias("microphone", call, "micPermissionResult");
    }

    @PermissionCallback
    private void micPermissionResult(PluginCall call) {
        call.resolve(new JSObject().put("granted", getPermissionState("microphone") == PermissionState.GRANTED));
    }

    @PluginMethod
    public void openAppSettings(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", getContext().getPackageName(), null));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("설정을 열지 못했어요");
        }
    }

    /* ---------- 바깥 브라우저로 열기 ---------- */
    /** 클립보드 글 읽기 (밴드에서 복사한 방송 일정 붙여넣기) */
    @PluginMethod
    public void readClipboard(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            JSObject ret = new JSObject();
            try {
                ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                String text = "";
                if (cm != null && cm.hasPrimaryClip()) {
                    ClipData clip = cm.getPrimaryClip();
                    if (clip != null && clip.getItemCount() > 0) {
                        CharSequence cs = clip.getItemAt(0).coerceToText(getContext());
                        if (cs != null) text = cs.toString();
                    }
                }
                ret.put("text", text);
                call.resolve(ret);
            } catch (Exception e) {
                call.reject("clipboard");
            }
        });
    }

    @PluginMethod
    public void openExternalUrl(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isEmpty()) {
            call.reject("주소가 없어요");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("열 수 있는 앱이 없어요");
        }
    }

    /* ---------- 연락처 한 사람 고르기 ---------- */
    @PluginMethod
    public void pickContact(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(call, i, "contactPicked");
    }

    @ActivityCallback
    private void contactPicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.resolve(new JSObject());
            return;
        }
        String[] cols = {
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        };
        try (Cursor c = getContext().getContentResolver().query(result.getData().getData(), cols, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                JSObject o = new JSObject();
                o.put("name", c.getString(0));
                o.put("phone", c.getString(1));
                call.resolve(o);
                return;
            }
        } catch (Exception ignored) {
        }
        call.resolve(new JSObject());
    }

    /* ---------- 음성 인식 (말 → 글자) ---------- */
    @PluginMethod
    public void startSpeechRecognition(PluginCall call) {
        if (getPermissionState("microphone") != PermissionState.GRANTED) {
            call.reject("마이크 권한이 없어요");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(getContext())) {
            call.reject("이 휴대폰에는 음성 인식 기능이 없어요");
            return;
        }
        language = call.getString("language", "ko-KR");
        main.post(() -> {
            listening = true;
            listen();
            call.resolve();
        });
    }

    @PluginMethod
    public void stopSpeechRecognition(PluginCall call) {
        main.post(() -> {
            listening = false;
            destroyRecognizer();
            call.resolve();
        });
    }

    private void listen() {
        if (!listening) return;
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
                recognizer.setRecognitionListener(new Listener());
            }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            recognizer.startListening(i);
        } catch (Exception e) {
            destroyRecognizer();
            listenAgain(600);
        }
    }

    /** 한 문장이 끝나면 다시 들어요 (끝내기를 누를 때까지) */
    private void listenAgain(long delay) {
        if (listening) main.postDelayed(this::listen, delay);
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
            try { recognizer.destroy(); } catch (Exception ignored) {}
            recognizer = null;
        }
    }

    @Override
    protected void handleOnDestroy() {
        listening = false;
        destroyRecognizer();
        super.handleOnDestroy();
    }

    private class Listener implements RecognitionListener {
        @Override public void onReadyForSpeech(Bundle params) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rmsdB) {}
        @Override public void onBufferReceived(byte[] buffer) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onPartialResults(Bundle partialResults) {}
        @Override public void onEvent(int eventType, Bundle params) {}

        @Override
        public void onResults(Bundle results) {
            ArrayList<String> m = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (m != null && !m.isEmpty() && m.get(0) != null && !m.get(0).trim().isEmpty()) {
                notifyListeners("speechResult", new JSObject().put("text", m.get(0).trim()));
            }
            listenAgain(250);
        }

        @Override
        public void onError(int error) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                listening = false;
                destroyRecognizer();
                notifyListeners("speechError", new JSObject().put("code", error));
                return;
            }
            // 말이 없었거나(시간 초과) 잠깐 바빴던 경우: 새로 만들어서 다시 들어요
            destroyRecognizer();
            listenAgain(error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? 200 : 800);
        }
    }
}
