package com.kimminja.taegeuk.widget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

/** 위젯을 한꺼번에 새로 그리고, 자정에 다시 그리도록 예약해요. */
public final class WidgetUpdater {
    static final String ACTION_MIDNIGHT = "com.kimminja.taegeuk.widget.MIDNIGHT";
    static final String EXTRA_ACT = "tw_act";
    static final String EXTRA_DATE = "tw_date";
    static final String ACTION_QUICK = "com.kimminja.taegeuk.widget.QUICK";
    static final String EXTRA_KIND = "tw_kind";

    private WidgetUpdater() {}

    public static void updateAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        for (int id : mgr.getAppWidgetIds(new ComponentName(ctx, TodayWidgetProvider.class))) {
            TodayWidgetProvider.render(ctx, mgr, id);
        }
        for (int id : mgr.getAppWidgetIds(new ComponentName(ctx, MonthWidgetProvider.class))) {
            MonthWidgetProvider.render(ctx, mgr, id);
        }
        for (int id : mgr.getAppWidgetIds(new ComponentName(ctx, ChecklistWidgetProvider.class))) {
            ChecklistWidgetProvider.render(ctx, mgr, id);
        }
        scheduleMidnight(ctx);
    }

    /** 앱을 열지 않아도 날짜가 바뀌면 위젯이 다음 날로 넘어가요 (정확한 알람 권한은 필요 없어요). */
    static void scheduleMidnight(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Calendar c = WidgetData.today();
        c.add(Calendar.DAY_OF_MONTH, 1);
        c.add(Calendar.MINUTE, 1);
        // 내일이 주일·치성이면 오늘 밤 11:31 에 미리 넘겨요 (자시부터 그날)
        Calendar eve = (Calendar) c.clone();
        eve.add(Calendar.MINUTE, -31);   // 내일 0:00 - 30분 = 오늘 23:30
        eve.add(Calendar.MINUTE, 1);
        Calendar nowC = Calendar.getInstance();
        Calendar day0 = (Calendar) c.clone();
        day0.add(Calendar.MINUTE, -1);
        if (WidgetData.early.contains("," + WidgetData.iso(day0) + ",") && eve.after(nowC)) c = eve;
        Intent i = new Intent(ctx, TodayWidgetProvider.class).setAction(ACTION_MIDNIGHT);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 7301, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.set(AlarmManager.RTC, c.getTimeInMillis(), pi);
    }

    /** 위젯을 누르면 앱이 열려요. */
    static PendingIntent openApp(Context ctx) {
        return openApp(ctx, null, null);
    }

    /** 위젯 단추: 앱을 열면서 바로 그 화면으로 (act = day·prayer·study·chiseong·schedule) */
    static PendingIntent openApp(Context ctx, String act, String date) {
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        if (i == null) i = new Intent();
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int code = 7300;
        if (act != null) {
            i.putExtra(EXTRA_ACT, act);
            if (date != null) i.putExtra(EXTRA_DATE, date);
            code = 7400 + ((act + "|" + (date == null ? "" : date)).hashCode() & 0xFFFFF);
        }
        return PendingIntent.getActivity(ctx, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** 위젯 바로 체크 단추 (kind = prayer · suryeon · study · undo · routine:아이디) — 앱을 열지 않아요 */
    static PendingIntent quick(Context ctx, String kind) {
        Intent i = new Intent(ctx, TodayWidgetProvider.class).setAction(ACTION_QUICK).putExtra(EXTRA_KIND, kind);
        return PendingIntent.getBroadcast(ctx, 7500 + (kind.hashCode() & 0xFFFFF), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
