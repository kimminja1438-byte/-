package com.kimminja.taegeuk.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.widget.RemoteViews;

import com.kimminja.taegeuk.R;

import org.json.JSONObject;

import java.util.Calendar;

/** 4×2 '이번 주' 위젯: 일~토 7칸 · 음력 · 치성 · 주일 · 기도/공부/치성 표시 · D-day */
public class WeekWidgetProvider extends AppWidgetProvider {

    static final int[] COL = {R.id.tw_c0, R.id.tw_c1, R.id.tw_c2, R.id.tw_c3, R.id.tw_c4, R.id.tw_c5, R.id.tw_c6};
    static final int[] WDV = {R.id.tw_w0, R.id.tw_w1, R.id.tw_w2, R.id.tw_w3, R.id.tw_w4, R.id.tw_w5, R.id.tw_w6};
    static final int[] NUM = {R.id.tw_n0, R.id.tw_n1, R.id.tw_n2, R.id.tw_n3, R.id.tw_n4, R.id.tw_n5, R.id.tw_n6};
    static final int[] SUB = {R.id.tw_s0, R.id.tw_s1, R.id.tw_s2, R.id.tw_s3, R.id.tw_s4, R.id.tw_s5, R.id.tw_s6};
    static final int[] MRK = {R.id.tw_m0, R.id.tw_m1, R.id.tw_m2, R.id.tw_m3, R.id.tw_m4, R.id.tw_m5, R.id.tw_m6};
    static final int[] EMO1 = {R.id.tw_e0, R.id.tw_e1, R.id.tw_e2, R.id.tw_e3, R.id.tw_e4, R.id.tw_e5, R.id.tw_e6};
    static final int[] EMO2 = {R.id.tw_f0, R.id.tw_f1, R.id.tw_f2, R.id.tw_f3, R.id.tw_f4, R.id.tw_f5, R.id.tw_f6};
    static final int[] SCH = {R.id.tw_t0, R.id.tw_t1, R.id.tw_t2, R.id.tw_t3, R.id.tw_t4, R.id.tw_t5, R.id.tw_t6};

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) render(ctx, mgr, id);
        WidgetUpdater.scheduleMidnight(ctx);
    }

    static void render(Context ctx, AppWidgetManager mgr, int id) {
        JSONObject data = WidgetData.load(ctx);
        WidgetData.Theme th = WidgetData.Theme.of(data);
        Calendar today = WidgetData.today();
        String todayIso = WidgetData.iso(today);

        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.tw_widget_week);
        v.setInt(R.id.tw_root, "setBackgroundResource", th.bg);
        v.setImageViewResource(R.id.tw_logo, th.logo);
        v.setViewVisibility(R.id.tw_photo, th.photo ? android.view.View.VISIBLE : android.view.View.GONE);
        if (th.photo) v.setImageViewResource(R.id.tw_photo, th.photoRes);

        Calendar c = (Calendar) today.clone();
        c.add(Calendar.DAY_OF_MONTH, -(today.get(Calendar.DAY_OF_WEEK) - 1));
        Calendar end = (Calendar) c.clone();
        end.add(Calendar.DAY_OF_MONTH, 6);
        v.setTextViewText(R.id.tw_title, (c.get(Calendar.MONTH) + 1) + "." + c.get(Calendar.DAY_OF_MONTH)
                + " – " + (end.get(Calendar.MONTH) + 1) + "." + end.get(Calendar.DAY_OF_MONTH));
        v.setTextColor(R.id.tw_title, th.photo ? 0xFFFFFFFF : th.ink);

        // 오른쪽 위: 다음 치성 · 성금 D-day
        SpannableStringBuilder badge = new SpannableStringBuilder();
        Object[] chi = WidgetData.nextChiseong(data, today);
        if (chi != null) append(badge, chi[0] + " " + WidgetData.dday((Integer) chi[1]), th.photo ? 0xFFFFFFFF : th.accent, true);
        int od = WidgetData.offerDday(data, today);
        if (od >= 0) {
            if (badge.length() > 0) append(badge, "  ·  ", th.sub, false);
            append(badge, "성금 " + WidgetData.dday(od), th.photo ? 0xFFB9F0C8 : 0xFF3C7A4A, true);
        }
        v.setTextViewText(R.id.tw_badge, badge);

        for (int i = 0; i < 7; i++) {
            String iso = WidgetData.iso(c);
            JSONObject d = WidgetData.day(data, iso);
            int w = i;
            boolean isToday = iso.equals(todayIso);
            boolean hol = d != null && !d.optString("hol").isEmpty();
            int numColor = (w == 0 || hol) ? th.accent : (w == 6 ? th.blue : th.ink);

            v.setTextViewText(WDV[i], WidgetData.WD[w]);
            v.setTextColor(WDV[i], w == 0 ? th.accent : (w == 6 ? th.blue : th.sub));
            v.setTextViewText(NUM[i], String.valueOf(c.get(Calendar.DAY_OF_MONTH)));
            v.setTextColor(NUM[i], numColor);
            v.setInt(COL[i], "setBackgroundResource", isToday ? th.todayCell : android.R.color.transparent);

            // 둘째 줄: 치성 이름 > 공휴일 > 주일 > 음력
            SpannableStringBuilder sub = new SpannableStringBuilder();
            if (d != null) {
                String ev = d.optString("ev");
                if (!ev.isEmpty()) append(sub, ev, th.accent, true);
                else if (hol) append(sub, d.optString("hol").replace(" 대체공휴일", "(대체)"), th.accent, false);
                else if (d.optBoolean("juil")) append(sub, "주일", th.blue, true);
                else append(sub, d.optString("lun"), th.sub, false);
            }
            v.setTextViewText(SUB[i], sub);

            // 셋째 줄: 기도 ● · 공부 ● · 치성 ●
            SpannableStringBuilder mk = new SpannableStringBuilder();
            if (d != null) {
                int pc = d.optInt("pc");
                if (pc > 0) append(mk, "●" + pc, th.accent, true);
                if (d.optBoolean("st")) append(mk, "●", th.blue, false);
                if (d.optBoolean("ch")) append(mk, "●", 0xFFE2894A, false);
            }
            v.setTextViewText(MRK[i], mk);

            // 넷째 줄: 이모티콘 그림 (최대 2개) · 다섯째 줄: 일정 제목
            setIcon(v, EMO1[i], WidgetData.icon(data, WidgetData.emo(d, 0)));
            setIcon(v, EMO2[i], WidgetData.icon(data, WidgetData.emo(d, 1)));
            String sl = WidgetData.schLine(d, false);
            v.setViewVisibility(SCH[i], sl.isEmpty() ? android.view.View.GONE : android.view.View.VISIBLE);
            v.setTextViewText(SCH[i], sl);
            v.setTextColor(SCH[i], th.ink);
            v.setOnClickPendingIntent(COL[i], WidgetUpdater.openApp(ctx, "day", iso));
            c.add(Calendar.DAY_OF_MONTH, 1);
        }

        v.setTextColor(R.id.tw_add, th.photo ? 0xFFFFFFFF : th.accent);
        v.setOnClickPendingIntent(R.id.tw_add, WidgetUpdater.openApp(ctx, "schedule", todayIso));
        v.setOnClickPendingIntent(R.id.tw_root, WidgetUpdater.openApp(ctx));
        mgr.updateAppWidget(id, v);
    }

    static void setIcon(RemoteViews v, int viewId, android.graphics.Bitmap bm) {
        if (bm == null) {
            v.setViewVisibility(viewId, android.view.View.GONE);
        } else {
            v.setImageViewBitmap(viewId, bm);
            v.setViewVisibility(viewId, android.view.View.VISIBLE);
        }
    }

    private static void append(SpannableStringBuilder sb, String text, int color, boolean bold) {
        int s = sb.length();
        sb.append(text);
        sb.setSpan(new ForegroundColorSpan(color), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (bold) sb.setSpan(new StyleSpan(Typeface.BOLD), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
}
