package com.kimminja.taegeuk.widget;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Icon;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 기도 시간 알림 (휴대폰이 직접 울려요).
 * - 앱이 앞으로 90일치 기도 시간 목록을 넘겨주면 휴대폰에 보관해요.
 *   그중 가까운 이틀치만 알람을 걸고, 알림이 울릴 때 · 자정 · 휴대폰을 켤 때마다 다음 것을 스스로 이어 걸어요.
 *   그래서 앱을 열지 않고 위젯만 써도 기도 알림이 끊기지 않아요. (목록이 거의 끝나가면 앱을 한 번 열어달라고 알려요)
 * - 알림에 [✓ 모셨어요] 단추가 있어서, 누르면 앱을 열지 않고 그 기도가 체크돼요.
 *   (위젯 바로 체크처럼 잠깐 적어뒀다가, 앱을 열 때 달력에 들어가요)
 */
public class PrayerAlarm extends BroadcastReceiver {
    static final String ACTION_FIRE = "com.kimminja.taegeuk.widget.PRAYER_FIRE";
    static final String ACTION_DONE = "com.kimminja.taegeuk.widget.PRAYER_DONE";
    static final String KEY_LIST = "prayer_alarms";
    static final String CH = "tg_prayer";
    static final int NID_BASE = 20000;

    static final String KEY_ARMED = "prayer_armed";
    static final String KEY_LOW = "prayer_low_warned";
    static final long WINDOW = 48L * 60 * 60 * 1000;   // 가까운 이틀치만 걸어둬요

    /** 앱이 새 목록을 주면: 걸어둔 알람을 지우고 새 목록으로 다시 걸어요 */
    static synchronized void schedule(Context ctx, JSONArray list) {
        cancelArmed(ctx);
        ctx.getSharedPreferences(WidgetData.PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_LIST, list.toString()).remove(KEY_LOW).apply();
        rearm(ctx);
    }

    static JSONArray stored(Context ctx) {
        try { return new JSONArray(ctx.getSharedPreferences(WidgetData.PREFS, Context.MODE_PRIVATE).getString(KEY_LIST, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private static PendingIntent firePi(Context ctx, int id) {
        Intent i = new Intent(ctx, PrayerAlarm.class).setAction(ACTION_FIRE).putExtra("id", id);
        return PendingIntent.getBroadcast(ctx, 40000 + id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void cancelArmed(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        String armed = ctx.getSharedPreferences(WidgetData.PREFS, Context.MODE_PRIVATE).getString(KEY_ARMED, "");
        for (String s : armed.split(",")) {
            if (s.isEmpty()) continue;
            try { am.cancel(firePi(ctx, Integer.parseInt(s))); } catch (Exception e) { /* 그대로 */ }
        }
        ctx.getSharedPreferences(WidgetData.PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ARMED, "").apply();
    }

    /** 보관한 목록에서 앞으로 이틀 안의 알림을 걸어요 (여러 번 불려도 괜찮아요) */
    static synchronized void rearm(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        JSONArray list = stored(ctx);
        long now = System.currentTimeMillis(), last = 0;
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        StringBuilder armed = new StringBuilder();
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o == null) continue;
            long at = o.optLong("at");
            last = Math.max(last, at);
            if (at <= now || at > now + WINDOW) continue;
            int id = o.optInt("id");
            PendingIntent pi = firePi(ctx, id);
            try {
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            }
            armed.append(id).append(',');
        }
        ctx.getSharedPreferences(WidgetData.PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ARMED, armed.toString()).apply();
        // 목록이 5일 안에 끝나면: 앱을 한 번 열어달라고 한 번만 알려요
        if (list.length() > 0 && last > 0 && last < now + 5L * 24 * 60 * 60 * 1000) warnLow(ctx);
    }

    private static void warnLow(Context ctx) {
        android.content.SharedPreferences p = ctx.getSharedPreferences(WidgetData.PREFS, Context.MODE_PRIVATE);
        if (p.getBoolean(KEY_LOW, false)) return;
        p.edit().putBoolean(KEY_LOW, true).apply();
        try {
            JSONObject o = new JSONObject();
            o.put("id", 999999);
            o.put("title", "🙏 기도 알림을 이어서 걸어주세요");
            o.put("body", "앱을 한 번 열면 다음 석 달치 기도 알림이 다시 걸려요.");
            o.put("date", WidgetData.iso(WidgetData.today()));
            o.put("plain", true);
            show(ctx, o);
        } catch (Exception e) { /* 조용히 */ }
    }

    /** 위젯·알림에서 이미 체크한 기도면 알리지 않아요 */
    private static boolean alreadyChecked(Context ctx, JSONObject o) {
        String date = o.optString("date");
        int slot = o.optInt("slot", -1);
        JSONArray a = WidgetData.pending(ctx);
        for (int i = 0; i < a.length(); i++) {
            JSONObject p = a.optJSONObject(i);
            if (p != null && "prayer".equals(p.optString("kind")) && date.equals(p.optString("k")) && p.has("slot") && p.optInt("slot") == slot) return true;
        }
        return false;
    }

    private static JSONObject find(Context ctx, int id) {
        JSONArray a = stored(ctx);
        for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && o.optInt("id") == id) return o; }
        return null;
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (a == null) return;
        if (ACTION_FIRE.equals(a)) {
            JSONObject o = find(ctx, intent.getIntExtra("id", -1));
            if (o != null && !alreadyChecked(ctx, o)) show(ctx, o);
            rearm(ctx);   // 다음 알림을 이어서 걸어요
        } else if (ACTION_DONE.equals(a)) {
            String date = intent.getStringExtra("date");
            int slot = intent.getIntExtra("slot", -1);
            String name = intent.getStringExtra("name");
            int nid = intent.getIntExtra("nid", 0);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nid != 0) nm.cancel(nid);
            String msg = WidgetData.markPrayer(ctx, date, slot, name);
            WidgetUpdater.updateAll(ctx);
            WidgetData.toast(ctx, msg);
        } else if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)
                || Intent.ACTION_TIME_CHANGED.equals(a) || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) {
            rearm(ctx);
            WidgetUpdater.scheduleMidnight(ctx);
        }
    }

    private static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CH) != null) return;
        NotificationChannel c = new NotificationChannel(CH, "기도 시간 알림", NotificationManager.IMPORTANCE_HIGH);
        c.setDescription("기도 시간이 되면 알려줘요. [✓ 모셨어요]로 바로 체크해요.");
        nm.createNotificationChannel(c);
    }

    @SuppressWarnings("deprecation")
    private static void show(Context ctx, JSONObject o) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        ensureChannel(ctx);
        int id = o.optInt("id"), nid = NID_BASE + id;
        String date = o.optString("date");
        Intent done = new Intent(ctx, PrayerAlarm.class).setAction(ACTION_DONE)
                .putExtra("date", date).putExtra("slot", o.optInt("slot", -1))
                .putExtra("name", o.optString("name")).putExtra("nid", nid);
        PendingIntent donePi = PendingIntent.getBroadcast(ctx, nid, done, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        int icon = ctx.getApplicationInfo().icon;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CH) : new Notification.Builder(ctx);
        b.setSmallIcon(icon)
                .setContentTitle(o.optString("title"))
                .setContentText(o.optString("body"))
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(WidgetUpdater.openApp(ctx, o.optBoolean("plain") ? "day" : "prayer", date));
        if (!o.optBoolean("plain")) b.addAction(new Notification.Action.Builder(Icon.createWithResource(ctx, icon), "✓ 모셨어요", donePi).build());
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        try { nm.notify(nid, b.build()); } catch (Exception e) { /* 조용히 */ }
    }
}
