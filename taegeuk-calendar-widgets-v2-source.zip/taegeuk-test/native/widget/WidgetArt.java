package com.kimminja.taegeuk.widget;
import android.graphics.*;
import android.text.TextPaint;
import android.text.TextUtils;
import org.json.*;
import java.util.*;

/** Native bitmaps use the app's exported emoji images and actual prayer slots. */
final class WidgetArt {
    static final int[][] FOUR={{1,1,1},{0,1,0},{0,0,0},{1,0,1}};
    static final float[] ANGLES={-56.31f,56.31f,123.69f,236.31f};
    static final int[][] EIGHT={{1,1,1},{0,1,1},{0,1,0},{0,0,1},{0,0,0},{1,0,0},{1,0,1},{1,1,0}};
    static Bitmap prayer(JSONObject d,int size){
        Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);Paint p=new Paint(3);
        c.translate(size/2f,size/2f);c.scale(size/80f,size/80f);
        int n=d==null?4:d.optInt("pt",4);if(n!=8)n=4;
        JSONArray slots=d==null?null:d.optJSONArray("slots");
        int count=d==null?0:d.optInt("pc");
        c.save();c.rotate(n==8?73:33.69f);
        p.setColor(0xFFCD2E3A);c.drawCircle(0,0,17,p);
        p.setColor(0xFF0047A0);c.drawArc(new RectF(-17,-17,17,17),0,180,true,p);
        c.drawCircle(-8.5f,0,8.5f,p);p.setColor(0xFFCD2E3A);c.drawCircle(8.5f,0,8.5f,p);c.restore();
        for(int i=0;i<n;i++){
            int on=slots==null?(i<count?1:0):slots.optInt(i);
            p.setColor(on==2?0xFFB97825:on>0?0xFF467B77:0xFFD4D0CB);
            if(n==4){c.save();c.rotate(ANGLES[i]);p.setStyle(Paint.Style.FILL);
                for(int k=0;k<3;k++){float y=-25.5f-k*4.25f-2.83f;
                    if(FOUR[i][k]==1)c.drawRect(-8.5f,y,8.5f,y+2.83f,p);
                    else{c.drawRect(-8.5f,y,-.71f,y+2.83f,p);c.drawRect(.71f,y,8.5f,y+2.83f,p);}}
                c.restore();
            }else{p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.4f);
                for(int k=0;k<3;k++){float r=23+k*4.3f,a=315+i*45-90+3;
                    RectF box=new RectF(-r,-r,r,r);
                    if(EIGHT[i][k]==1)c.drawArc(box,a,39,false,p);
                    else{c.drawArc(box,a,17,false,p);c.drawArc(box,a+22,17,false,p);}}
                p.setStyle(Paint.Style.FILL);
            }
        }return b;
    }
    static void text(Canvas c,String s,float x,float y,float width,float size,int color,boolean bold){
        TextPaint p=new TextPaint(3);p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);
        c.drawText(TextUtils.ellipsize(s,p,Math.max(1,width),TextUtils.TruncateAt.END).toString(),x,y,p);
    }
    static Bitmap cell(JSONObject data,JSONObject d,int date,int weekday,boolean active,boolean today,boolean selected,int width,int height,float scale,WidgetData.Theme th){
        float factor=1.6f;Bitmap b=Bitmap.createBitmap(Math.max(40,(int)(width*factor)),Math.max(48,(int)(height*factor)),Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(b);c.scale(factor,factor);Paint p=new Paint(3);
        if(today||selected){p.setColor(today?0xFFFBE6DE:0xFFEAF0EA);c.drawRoundRect(new RectF(1,1,width-1,height-1),6,6,p);}
        p.setColor(0x227E776F);c.drawLine(width-1,0,width-1,height,p);c.drawLine(0,height-1,width,height-1,p);
        int ink=active?th.ink:th.sub;float fs=11*scale,line=fs+3,y=19*scale;
        text(c,String.valueOf(date),3,y,width-5,16*scale,active?(weekday==0||d!=null&&!d.optString("hol").isEmpty()?th.accent:weekday==6?th.blue:ink):th.sub,true);
        if(!active||d==null)return b;
        if(d.optBoolean("juil"))text(c,"주일",width*.47f,y,width*.52f,9*scale,th.blue,true);
        y=23*scale;
        JSONObject cal=d.optJSONObject("calendar");if(cal==null)return b;
        ArrayList<String> lines=new ArrayList<>();
        for(String key:new String[]{"meta","labels"}){JSONArray a=cal.optJSONArray(key);if(a!=null)for(int i=0;i<a.length();i++)lines.add(a.optString(i));}
        JSONArray items=cal.optJSONArray("items"),emo=cal.optJSONArray("emo");
        String marks=(cal.optBoolean("period")?"🌸 ":"")+(cal.optBoolean("showStudy")&&d.optBoolean("st")?"📚 ":"")+(cal.optBoolean("showSuryeon")&&d.optInt("sr")>0?"수련"+d.optInt("sr")+" ":"")+(cal.optBoolean("showChiseong")&&d.optBoolean("ch")?"🪷 ":"")+(cal.optBoolean("showMemo")?"✎ ":"")+(cal.optString("mood"));
        boolean pr=cal.optBoolean("showPrayer")&&hasPrayer(d);
        boolean pictures=pr||emo!=null&&emo.length()>0;
        float reserve=(pictures?20*scale:0)+(marks.isEmpty()?0:line);
        int capacity=Math.max(0,(int)((height-y-reserve-2)/line));
        int itemCount=items==null?0:items.length();int desired=lines.size()+Math.min(3,itemCount);
        boolean more=capacity<lines.size()+itemCount;int visible=Math.min(desired,Math.max(0,capacity-(more?1:0)));
        for(int i=0;i<visible;i++){
            String t=i<lines.size()?lines.get(i):items.optJSONObject(i-lines.size()).optString("title");
            text(c,t,3,y+fs,width-5,fs,i<lines.size()?th.sub:ink,false);y+=line;
        }
        int hidden=lines.size()+itemCount-visible;
        if(hidden>0&&capacity>0){text(c,"+"+hidden+"개",3,y+fs,width-5,fs,th.accent,true);y+=line;}
        if(hidden>0&&capacity==0)text(c,"+",width-10,12,9,10,th.accent,true);
        if(!marks.isEmpty()&&y+line<=height){text(c,marks,3,y+fs,width-5,fs,ink,false);y+=line;}
        if(pictures&&y+18*scale<=height){float x=2,sz=18*scale;
            if(pr){c.drawBitmap(prayer(d,64),null,new RectF(x,y-1,x+sz,y-1+sz),p);x+=sz;}
            int count=emo==null?0:emo.length(),shown=0;
            for(int i=0;i<count&&x+sz<=width-2;i++){
                Bitmap icon=WidgetData.icon(data,emo.optString(i));if(icon!=null){c.drawBitmap(icon,null,new RectF(x,y-1,x+sz,y-1+sz),p);x+=sz;shown++;}}
            if(shown<count)text(c,"+",width-9,height-3,9,10,th.accent,true);
        }
        return b;
    }
    static boolean hasPrayer(JSONObject d){if(d.optInt("pc")>0)return true;JSONArray a=d.optJSONArray("slots");if(a!=null)for(int i=0;i<a.length();i++)if(a.optInt(i)>0)return true;return false;}
}
