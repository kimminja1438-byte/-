package com.kimminja.taegeuk.widget;
import android.app.PendingIntent;
import android.appwidget.*;
import android.content.*;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import com.kimminja.taegeuk.R;
import org.json.*;
import java.util.*;

/** 큰 달력: 표시 설정 · 원본 이모티콘 · 태극 기록 · 선택 날짜 상세. */
public class MonthWidgetProvider extends AppWidgetProvider {
    static final String NAV="com.kimminja.taegeuk.widget.MONTH_NAV",SEL="com.kimminja.taegeuk.widget.MONTH_SEL";
    static android.content.SharedPreferences sp(Context c){return c.getSharedPreferences(WidgetData.PREFS,0);}
    static PendingIntent self(Context c,int id,String action,String value){Intent i=new Intent(c,MonthWidgetProvider.class).setAction(action).setData(android.net.Uri.parse("taegeuk-widget://month/"+id+"/"+android.net.Uri.encode(action+value))).putExtra("wid",id).putExtra("value",value);return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)render(c,m,id);WidgetUpdater.scheduleMidnight(c);}
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle o){render(c,m,id);}
    @Override public void onDeleted(Context c,int[] ids){for(int id:ids)sp(c).edit().remove("mw_off_"+id).remove("mw_sel_"+id).remove("mw_selday_"+id).apply();}
    @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);int id=i.getIntExtra("wid",-1);String value=i.getStringExtra("value");if(id<0||value==null)return;
        String today=WidgetData.iso(WidgetData.today());
        if(NAV.equals(i.getAction())){int off="0".equals(value)?0:sp(c).getInt("mw_off_"+id,0)+Integer.parseInt(value);off=Math.max(-1,Math.min(3,off));Calendar base=WidgetData.today();base.set(Calendar.DAY_OF_MONTH,1);base.add(Calendar.MONTH,off);
            sp(c).edit().putInt("mw_off_"+id,off).putString("mw_sel_"+id,"0".equals(value)?today:WidgetData.iso(base)).putString("mw_selday_"+id,today).apply();
        }else if(SEL.equals(i.getAction()))sp(c).edit().putString("mw_sel_"+id,value).putString("mw_selday_"+id,today).apply();else return;
        render(c,AppWidgetManager.getInstance(c),id);
    }
    static void render(Context ctx,AppWidgetManager mgr,int id){
        JSONObject data=WidgetData.load(ctx);WidgetData.Theme th=WidgetData.Theme.of(data);Calendar today=WidgetData.today();String ti=WidgetData.iso(today);
        Calendar base=(Calendar)today.clone();base.set(Calendar.DAY_OF_MONTH,1);int off=Math.max(-1,Math.min(3,sp(ctx).getInt("mw_off_"+id,0)));base.add(Calendar.MONTH,off);
        String sel=sp(ctx).getString("mw_selday_"+id,"").equals(ti)?sp(ctx).getString("mw_sel_"+id,""):"";if(sel.isEmpty())sel=off==0?ti:WidgetData.iso(base);
        int month=base.get(Calendar.MONTH),lead=base.get(Calendar.DAY_OF_WEEK)-1,weeks=(lead+base.getActualMaximum(Calendar.DAY_OF_MONTH)+6)/7;
        Bundle opts=mgr.getAppWidgetOptions(id);boolean landscape=ctx.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        int width=opts.getInt(landscape?AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH:AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,350);
        int height=opts.getInt(landscape?AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT:AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,580);
        width=Math.max(250,width);height=Math.max(280,height);float f=WidgetData.scale(data);
        boolean panel=height>=420;int header=70,footer=54,panelHeight=panel?100:0;int cellH=Math.max(28,(height-header-footer-panelHeight-16)/weeks),cellW=(width-16)/7;
        RemoteViews v=new RemoteViews(ctx.getPackageName(),R.layout.tw_widget_month);v.setInt(R.id.tw_root,"setBackgroundResource",th.bg);
        v.setTextViewText(R.id.tw_title,base.get(Calendar.YEAR)+"년 "+(month+1)+"월");v.setTextColor(R.id.tw_title,th.ink);WidgetData.sz(v,R.id.tw_title,18,f);
        v.setOnClickPendingIntent(R.id.tw_m_prev,self(ctx,id,NAV,"-1"));v.setOnClickPendingIntent(R.id.tw_m_next,self(ctx,id,NAV,"1"));v.setOnClickPendingIntent(R.id.tw_m_today,self(ctx,id,NAV,"0"));
        v.setOnClickPendingIntent(R.id.tw_refresh,WidgetUpdater.quick(ctx,"refresh"));
        int[] wd={R.id.tw_mw0,R.id.tw_mw1,R.id.tw_mw2,R.id.tw_mw3,R.id.tw_mw4,R.id.tw_mw5,R.id.tw_mw6};
        for(int i=0;i<7;i++)v.setTextColor(wd[i],i==0?th.accent:i==6?th.blue:th.sub);
        Calendar c=(Calendar)base.clone();c.add(Calendar.DAY_OF_MONTH,-lead);v.removeAllViews(R.id.tw_month_rows);
        for(int r=0;r<weeks;r++){RemoteViews row=new RemoteViews(ctx.getPackageName(),R.layout.tw_month_row);
            for(int col=0;col<7;col++){String iso=WidgetData.iso(c);JSONObject d=WidgetData.day(data,iso);RemoteViews cell=new RemoteViews(ctx.getPackageName(),R.layout.tw_month_cell);
                cell.setImageViewBitmap(R.id.tw_month_art,WidgetArt.cell(data,d,c.get(Calendar.DAY_OF_MONTH),col,c.get(Calendar.MONTH)==month,iso.equals(ti),iso.equals(sel),cellW,cellH,f,th));
                cell.setContentDescription(R.id.tw_month_art,iso+" · 눌러서 일정과 기록 전체 보기");cell.setOnClickPendingIntent(R.id.tw_month_art,panel?self(ctx,id,SEL,iso):WidgetUpdater.openApp(ctx,"day",iso));row.addView(R.id.tw_month_row,cell);c.add(Calendar.DAY_OF_MONTH,1);}
            v.addView(R.id.tw_month_rows,row);
        }
        JSONObject day=WidgetData.day(data,sel);JSONObject cal=day==null?null:day.optJSONObject("calendar");
        v.setViewVisibility(R.id.tw_m_panel,panel?View.VISIBLE:View.GONE);
        v.setTextViewText(R.id.tw_m_dhead,sel.substring(5).replace('-', '/')+" 일정과 기록 ›");v.setTextColor(R.id.tw_m_dhead,th.ink);
        v.setOnClickPendingIntent(R.id.tw_m_dhead,WidgetUpdater.openApp(ctx,"day",sel));
        ArrayList<String> details=new ArrayList<>();if(cal!=null){for(String key:new String[]{"meta","labels"}){JSONArray a=cal.optJSONArray(key);if(a!=null)for(int i=0;i<a.length();i++)details.add(a.optString(i));}JSONArray a=cal.optJSONArray("items");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)details.add(x.optString("time")+" "+x.optString("title"));}}
        String line=day==null?"앱을 열어 최신 정보를 불러오세요":details.isEmpty()?"일정 없음 · 눌러서 기록 전체 보기":android.text.TextUtils.join(" · ",details);
        v.setTextViewText(R.id.tw_m_detail,line);v.setTextColor(R.id.tw_m_detail,th.sub);v.setOnClickPendingIntent(R.id.tw_m_detail,WidgetUpdater.openApp(ctx,"day",sel));
        v.setImageViewBitmap(R.id.tw_m_prayer,WidgetArt.prayer(day,160));v.setOnClickPendingIntent(R.id.tw_m_prayer,WidgetUpdater.openApp(ctx,"prayer",sel));
        v.setViewVisibility(R.id.tw_m_prayer,cal==null||cal.optBoolean("showPrayer")?View.VISIBLE:View.GONE);
        boolean isToday=sel.equals(ti);int pc=day==null?0:day.optInt("pc"),pt=day==null?4:day.optInt("pt",4);
        v.setTextViewText(R.id.tw_mq_prayer,(isToday?"오늘 기도":sel.substring(5)+" 기도")+"\n"+pc+"/"+pt+"회");
        v.setOnClickPendingIntent(R.id.tw_mq_prayer,isToday&&pc<pt?WidgetUpdater.quick(ctx,"prayer"):WidgetUpdater.openApp(ctx,"prayer",sel));
        v.setTextViewText(R.id.tw_mq_su,(isToday?"오늘 수련":sel.substring(5)+" 수련")+"\n"+(day==null?0:day.optInt("sr"))+"회");
        v.setOnClickPendingIntent(R.id.tw_mq_su,isToday?WidgetUpdater.quick(ctx,"suryeon"):WidgetUpdater.openApp(ctx,"suryeon",sel));
        v.setOnClickPendingIntent(R.id.tw_mq_sch,WidgetUpdater.openApp(ctx,"schedule",sel));v.setOnClickPendingIntent(R.id.tw_mq_undo,WidgetUpdater.quick(ctx,"undo"));
        for(int x:new int[]{R.id.tw_mq_prayer,R.id.tw_mq_su,R.id.tw_mq_sch,R.id.tw_mq_undo}){v.setTextColor(x,th.ink);WidgetData.sz(v,x,12,f);}
        mgr.updateAppWidget(id,v);
    }
}
