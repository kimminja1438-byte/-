package com.kimminja.taegeuk.widget;

import android.content.Intent;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * 앱(웹 화면)과 위젯 사이의 다리.
 * - 앱 → 위젯: TaegeukWidget.update({json}) 으로 달력 정보를 넘겨줘요.
 * - 위젯 → 앱: 위젯 단추(기도·공부·치성·일정·날짜)를 누르면 어떤 단추였는지 앱에 알려줘요.
 */
@CapacitorPlugin(name = "TaegeukWidget")
public class TaegeukWidgetPlugin extends Plugin {

    /** 아직 앱이 처리하지 않은 위젯 단추 (act=무엇, date=어느 날) */
    private static JSObject pending = null;

    @Override
    public void load() {
        if (getActivity() != null) keep(getActivity().getIntent());
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        if (keep(intent)) notifyListeners("widgetAction", new JSObject());
    }

    private static boolean keep(Intent i) {
        if (i == null) return false;
        String act = i.getStringExtra(WidgetUpdater.EXTRA_ACT);
        if (act == null) return false;
        JSObject o = new JSObject();
        o.put("act", act);
        o.put("date", i.getStringExtra(WidgetUpdater.EXTRA_DATE));
        pending = o;
        i.removeExtra(WidgetUpdater.EXTRA_ACT);
        i.removeExtra(WidgetUpdater.EXTRA_DATE);
        return true;
    }

    @PluginMethod
    public void takeAction(PluginCall call) {
        JSObject r = pending == null ? new JSObject() : pending;
        pending = null;
        call.resolve(r);
    }

    /** 위젯에서 바로 체크한 기록을 앱이 가져가요 (가져가면 위젯 쪽은 비워요) */
    @PluginMethod
    public void takeQuick(PluginCall call) {
        JSObject r = new JSObject();
        try {
            r.put("items", new JSArray(WidgetData.takePending(getContext()).toString()));
        } catch (Exception e) {
            r.put("items", new JSArray());
        }
        call.resolve(r);
    }

    @PluginMethod
    public void ackQuick(PluginCall call){
        try{WidgetData.acknowledge(getContext(),new org.json.JSONArray(call.getString("keys","[]")));call.resolve();}
        catch(Exception e){call.reject("체크 반영 확인 실패");}
    }

    /* ===== 자동 백업 =====
     * 앱 기록을 휴대폰 안 파일 하나에 늘 같이 적어둬요.
     * 이 파일은 안드로이드 '구글 자동 백업'에 함께 올라가서, 새 휴대폰이나 다시 설치할 때 되살릴 수 있어요. */
    static final String BACKUP_FILE = "taegeuk_auto_backup.json";

    @PluginMethod
    public void saveBackup(PluginCall call) {
        String json = call.getString("json");
        if (json == null || json.isEmpty()) { call.reject("내용이 없어요"); return; }
        try {
            java.io.File dir = getContext().getFilesDir();
            java.io.File tmp = new java.io.File(dir, BACKUP_FILE + ".tmp");
            try (java.io.FileOutputStream o = new java.io.FileOutputStream(tmp)) {
                o.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
            java.io.File dst = new java.io.File(dir, BACKUP_FILE);
            if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst); }
            call.resolve();
        } catch (Exception e) {
            call.reject("백업 파일을 쓰지 못했어요");
        }
    }

    @PluginMethod
    public void loadBackup(PluginCall call) {
        JSObject r = new JSObject();
        try {
            java.io.File f = new java.io.File(getContext().getFilesDir(), BACKUP_FILE);
            if (f.exists() && f.length() > 0) {
                byte[] b = new byte[(int) f.length()];
                try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                    int off = 0;
                    while (off < b.length) { int n = in.read(b, off, b.length - off); if (n < 0) break; off += n; }
                }
                r.put("json", new String(b, java.nio.charset.StandardCharsets.UTF_8));
                r.put("time", f.lastModified());
            }
        } catch (Exception e) { /* 없으면 빈 값 */ }
        call.resolve(r);
    }

    /** 앱이 앞으로의 기도 시간 알림 목록을 넘겨줘요 ([] 이면 모두 꺼요) */
    @PluginMethod
    public void schedulePrayers(PluginCall call) {
        String json = call.getString("json");
        try {
            PrayerAlarm.schedule(getContext(), new org.json.JSONArray(json == null ? "[]" : json));
            call.resolve();
        } catch (Exception e) {
            call.reject("기도 알림을 걸지 못했어요");
        }
    }

    @PluginMethod
    public void update(PluginCall call) {
        String json = call.getString("json");
        if (json == null) {
            call.reject("json이 없어요");
            return;
        }
        if(!WidgetData.acceptSnapshot(getContext(),json)){call.reject("pending widget checks");return;}
        WidgetUpdater.updateAll(getContext());
        call.resolve();
    }
}
