/* 테스트 앱으로 만들기: 진짜 앱(플레이스토어)과 따로 깔리게
   - 앱 아이디 뒤에 .test 를 붙여요 (com.kimminja.taegeuk.test)
   - 앱 이름을 "생활달력 테스트"로 바꿔요
   그래서 휴대폰의 진짜 앱과 기록은 그대로 남아요. */
const fs = require('fs'), path = require('path');
const APP = path.join(__dirname, 'android', 'app');
const bg = path.join(APP, 'build.gradle');
if (!fs.existsSync(bg)) { console.error('✗ android 폴더가 없어요. 위에 나온 오류를 찍어 보내 주세요.'); process.exit(1); }
let g = fs.readFileSync(bg, 'utf8');
if (!g.includes('applicationIdSuffix ".test"')) {
  if (/buildTypes\s*\{/.test(g)) g = g.replace(/buildTypes\s*\{/, 'buildTypes {\n        debug {\n            applicationIdSuffix ".test"\n            versionNameSuffix "-test"\n        }');
  else g = g.replace(/android\s*\{/, 'android {\n    buildTypes {\n        debug {\n            applicationIdSuffix ".test"\n            versionNameSuffix "-test"\n        }\n    }');
  fs.writeFileSync(bg, g);
}
const dv = path.join(APP, 'src', 'debug', 'res', 'values');
fs.mkdirSync(dv, { recursive: true });
fs.writeFileSync(path.join(dv, 'strings.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">생활달력 테스트</string>\n    <string name="title_activity_main">생활달력 테스트</string>\n</resources>\n');
console.log('  ✓ 테스트 앱으로 설정 (이름: 생활달력 테스트, 진짜 앱과 따로 깔려요)');
